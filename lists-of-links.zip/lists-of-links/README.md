# Lists of Links

Author:      Tim Reed <br>
Tags:        links, affiliate, amazon, associates, shortcode, wordpress, plugin <br>
Requires:    WordPress 6.0+ (tested on 6.9), PHP 7.4 <br>
License:     GPL-3.0-or-later <br>
License URI: https://www.gnu.org/licenses/gpl-3.0.html <br>

## Description

Lists of Links is a WordPress plugin that lets you maintain a database of links and display them on any page using the `[lists_of_links]` shortcode.

## Features

- Store links with category, title, URL, a one-line blurb, and tags
- Admin CRUD interface inside WP Admin
- Configure category heading tag (H1–H6) and list style (ul/ol/dl/p or table)
- Sort output by any column — leftmost column sorts first
- Filter links by category
- Choose which columns to display
- Output inherits all styles from your theme
- No link cloaking to comply with Amazon Associates ToS
- It's private and collects no information about your account, site, links, or anything else aside from the link-related data you input.

## Usage

Add the shortcode `[lists_of_links]` to any page or post to display your links using the heading and list styles configured in Settings.

Add `[lists_of_links_table]` to display your links in table format.

Add `[lists_of_links_grid]` to display your links in a bordered grid format.

All three shortcodes support these optional attributes:

**category** — filters output to a single category. Example: `[lists_of_links category="Health"]`

**tag** — filters output to links that have at least one of the specified tags (OR matching). Accepts one or more comma-separated tag words. Tags are matched whole-word and case-insensitively. Example: `[lists_of_links tag="fitness"]` or `[lists_of_links tag="health,fitness"]`. Tags are never shown in shortcode output.

**columns** — controls which columns are displayed and their order. Accepted values are `category`, `title`, and `description`, as a comma-separated list. The output is sorted by the leftmost column first, then remaining columns in order. Default is `columns="category,title,description"`. Example: `[lists_of_links_grid category="Health" columns="title,description"]` displays only title and description, sorted by title, for links in the Health category.

## Installation

**Option A: Via WordPress Admin**

1. Download `lists-of-links.zip` from the [Releases page](https://github.com/timothyreed1/lists-of-links/releases)
2. In WP Admin go to **Plugins > Add New > Upload Plugin**
3. Choose the zip file and click **Install Now**
4. Click **Activate Plugin**

**Option B: Via FTP or file manager**

1. Unzip `lists-of-links.zip`
2. Upload the `lists-of-links` folder to `/wp-content/plugins/`
3. Activate via **WP Admin > Plugins**

**After activation**

- Open **Lists of Links** in the admin menu to add and manage your links
- Open **Lists of Links > Settings** to configure display options
- Add `[lists_of_links]` to any page or post

## AI Disclosure

Although I designed and tested this software and documentation, I used Claude Code during development. I read and reviewed every line of output. 

## Frequently Asked Questions

*Is this compatible with Amazon Associates?*

**Yes. The plugin outputs plain anchor tags with no cloaking, which is required by Amazon's ToS.**

*Can I change the heading level for categories?*

**Yes. Go to Lists of Links > Settings and choose any heading level from H1 to H6.**

*Can I change the list style?*

**Yes. Go to Lists of Links > Settings and choose between bulleted list, numbered list, definition list, or plain paragraphs.**

*Where is my link data stored?*

**Data you enter is stored in a plugin-specific table called `lists_of_links` plus whatever table name prefix your site uses.**

*If I remove the plugin, what happens to its data?*

**Removing the plugin from your site will leave the `lists_of_links` table behind, which you can drop manually.**
